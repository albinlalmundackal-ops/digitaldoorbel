const int LDR_PIN=A0;
const int PIR_PIN=2;
const int ROOM_LED=8;
const int ALERT_LED=9;
const int BUZZER=10;
const int DARK_THRESHOLD=500;
void setup() {
  pinMode(2,INPUT);
  pinMode(8, OUTPUT);
  pinMode(9, OUTPUT);
  pinMode(10, OUTPUT);
  Serial.begin(9600);
  Serial.println("---smart room light and security system initialized");

}

void loop() {
  int ldrValue= analogRead(A0);
  int motionDetected=digitalRead(2);
  Serial.print("LDR Value: ");
  Serial.print(ldrValue);
  Serial.print("1 MOTION : ");
  Serial.print(motionDetected? "Detected": "NONE");
   
  if (ldrValue> DARK_THRESHOLD) {
    digitalWrite(8,HIGH);
  } else {
    digitalWrite(8,LOW);

  }
if (motionDetected == HIGH && ldrValue > DARK_THRESHOLD) {
  digitalWrite(9,HIGH);
  
}else {
  digitalWrite(9,LOW);
  noTone(10);
}
delay(200);
  }

