const int ldrpin=A0;
void setup() {
  Serial.begin(9600);

}

void loop() {
  // put your main code here, to run repeatedly:
int lightValue= analogRead(A0);
Serial.print("Light Value: ");
Serial.println(lightValue);
delay(500);
}
