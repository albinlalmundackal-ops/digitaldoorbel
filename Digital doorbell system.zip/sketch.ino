const int LED_PIN=13;
const int BUZZER_PIN=3;
const int PUSH_BUTTON=8;
void setup() {
  pinMode(13, OUTPUT);
  pinMode(3, OUTPUT);
  pinMode(8, INPUT_PULLUP);
 

}

void loop() {
  int buttonState= digitalRead(8);
  if (buttonState==LOW)
{
digitalWrite(13, HIGH);
delay(500);
tone(3,1000,300);
}
else
{
digitalWrite(13, LOW);
delay(1000);
}

}